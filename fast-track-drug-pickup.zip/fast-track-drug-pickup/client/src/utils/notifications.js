// client/src/utils/notifications.js
import { toast } from 'react-toastify';

// Function to show success notification
export const showSuccess = (message) => {
    toast.success(message);
};

// Function to show error notification
export const showError = (message) => {
    toast.error(message);
};