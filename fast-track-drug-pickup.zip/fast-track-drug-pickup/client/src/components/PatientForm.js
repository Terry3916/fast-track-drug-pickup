import React, { useState } from 'react';
import { registerPatient } from '../services/patientService';
import { showSuccess, showError } from '../utils/notifications';
import './PatientForm.css';

const PatientForm = ({ onPatientRegistered }) => {
    const [patient, setPatient] = useState({
        name: '',
        surname: '',
        dateOfBirth: '',
        sex: '',
        identityNumber: '',
        viralLoad: '',
        regimen: ''
    });
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        setPatient({ ...patient, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            await registerPatient(patient);
            showSuccess('Patient registered successfully!');
            setPatient({
                name: '',
                surname: '',
                dateOfBirth: '',
                sex: '',
                identityNumber: '',
                viralLoad: '',
                regimen: ''
            });

            onPatientRegistered();
        } catch (error) {
            showError(error.message || 'Failed to register patient.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="patient-form">
            <h2>Add Patient</h2>
            
            <div className="input-field">
                <input type="text" name="name" value={patient.name} onChange={handleChange} placeholder="Name" required />
            </div>

            <div className="input-field">
                <input type="text" name="surname" value={patient.surname} onChange={handleChange} placeholder="Surname" required />
            </div>

            <div className="input-field">
                <label htmlFor="dateOfBirth">DOB</label>
                <input
                    type="date"
                    name="dateOfBirth"
                    value={patient.dateOfBirth}
                    onChange={handleChange}
                    required
                />
            </div>

            <div className="input-field">
                <select name="sex" value={patient.sex} onChange={handleChange} required>
                    <option value="">Sex</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>

            <div className="input-field">
                <input type="text" name="identityNumber" value={patient.identityNumber} onChange={handleChange} placeholder="ID No" required />
            </div>

            <div className="input-field">
                <input type="number" name="viralLoad" value={patient.viralLoad} onChange={handleChange} placeholder="Viral Load" required />
            </div>

            <div className="input-field">
                <input type="text" name="regimen" value={patient.regimen} onChange={handleChange} placeholder="ARV Regimen" required />
            </div>

            <button
                type="submit"
                disabled={loading}
                className="submit-button"
                tabIndex={0}
            >
                {loading ? 'Registering...' : 'Register Patient'}
            </button>
        </form>
    );
};

export default PatientForm;