import React, { useState } from 'react';
import { login } from '../services/authService'; // Service for API requests
import { showSuccess, showError } from '../utils/notifications';

const LoginForm = () => {
    const [credentials, setCredentials] = useState({ username: '', password: '' });

    const handleChange = (e) => {
        setCredentials({ ...credentials, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await login(credentials);
            localStorage.setItem('token', response.token); // Store the token
            showSuccess('Logged in successfully!');
            // Redirect to dashboard or another page
            window.location.href = '/dashboard'; // Example redirection
        } catch (error) {
            showError(error.message || 'Login failed.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                name="username"
                onChange={handleChange}
                placeholder="Username"
                required
            />
            <input
                type="password"
                name="password"
                onChange={handleChange}
                placeholder="Password"
                required
            />
            <button type="submit">Log In</button>
        </form>
    );
};

export default LoginForm;