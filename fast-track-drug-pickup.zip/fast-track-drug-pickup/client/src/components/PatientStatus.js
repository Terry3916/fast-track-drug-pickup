import React from 'react';

const PatientStatus = ({ patient }) => {
    // Ensure the patient object is valid
    if (!patient) {
        return <div>No patient data available.</div>;
    }

    // Destructure patient properties for cleaner usage
    const {
        name,
        surname,
        viralLoad,
        eligibility,
        appointmentDate,
        notes
    } = patient;

    // Determine status based on viral load
    const status = viralLoad === 0 
        ? 'Undetectable (Fast Track Eligible)' 
        : viralLoad <= 1000 
            ? 'Suppressed' 
            : 'Unsuppressed';

    // Format the next appointment date or show 'N/A' if not available
    const formattedAppointmentDate = appointmentDate 
        ? new Date(appointmentDate).toLocaleDateString() 
        : 'N/A';

    return (
        <div>
            <h3>Patient Status</h3>
            <p>Name: {name} {surname}</p>
            <p>Viral Load: {viralLoad} copies/ml</p>
            <p>Status: {status}</p>
            <p>Eligibility for Fast Track Drug Pickup: {eligibility ? 'Yes' : 'No'}</p>
            <p>Next Appointment Date: {formattedAppointmentDate}</p>
            <p>Notes: {notes}</p>
        </div>
    );
};

export default PatientStatus;