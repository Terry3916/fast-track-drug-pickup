// src/pages/LoginRegisterPage.js
import React, { useState } from 'react';
import axios from 'axios';

const LoginRegisterPage = () => {
    const [isLogin, setIsLogin] = useState(true);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSwitch = () => {
        setIsLogin(!isLogin);
        setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (isLogin) {
                const response = await axios.post('http://localhost:5000/api/auth/login', { username, password });
                console.log('Login successful:', response.data);
                window.location.href = '/dashboard'; // Redirect to dashboard
            } else {
                const response = await axios.post('http://localhost:5000/api/users/register', { username, password });
                console.log('Registration successful:', response.data);
                alert('Registration successful, please login.');
                setIsLogin(true);
            }
        } catch (error) {
            console.error(error);
            setError('Invalid credentials or registration failed.');
        }
    };

    return (
        <div>
            <h2>{isLogin ? 'Login' : 'Register'}</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Username"
                    required
                />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                />
                <button type="submit">{isLogin ? 'Login' : 'Register'}</button>
                {error && <p>{error}</p>}
            </form>
            <button onClick={handleSwitch}>
                {isLogin ? 'Switch to Register' : 'Switch to Login'}
            </button>
        </div>
    );
};

export default LoginRegisterPage;