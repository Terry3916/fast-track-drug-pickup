// src/pages/About.js
import React from 'react';

const About = () => {
    return (
        <div style={styles.container}>
            <h2>About Us</h2>
            <p>
                This system is designed to streamline the drug pickup process for patients,
                ensuring timely access to medication and adherence to treatment protocols.
            </p>
            <h3>Key Features:</h3>
            <ul style={styles.featureList}>
                <li>Patient Management</li>
                <li>Eligibility Tracking for Fast Track Drug Pickup</li>
                <li>Reporting and Analytics</li>
                <li>Enhanced Adherence Counseling</li>
            </ul>
        </div>
    );
};

// Styles for the About component
const styles = {
    container: {
        padding: '20px',
        textAlign: 'left',
        maxWidth: '800px',
        margin: 'auto',
        fontFamily: 'Arial, sans-serif',
    },
    featureList: {
        listStyleType: 'square',
        paddingLeft: '20px',
    },
};

export default About; // Ensure this is a default export