// ManagePatients.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllPatients } from '../services/patientService';
import PatientForm from '../components/PatientForm';

const ManagePatients = () => {
    const [patients, setPatients] = useState([]);
    const [isAddingPatient, setIsAddingPatient] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchPatients = async () => {
            try {
                const data = await getAllPatients();
                setPatients(data);
            } catch (error) {
                console.error('Error fetching patients:', error);
            }
        };

        fetchPatients();
    }, []);

    const handleAddPatient = () => {
        setIsAddingPatient(true);
    };

    const handlePatientRegistered = () => {
        setIsAddingPatient(false);
    };

    return (
        <div style={{ padding: '20px' }}>
            <h2>Manage Patients</h2>
            <button onClick={handleAddPatient} style={{ marginBottom: '20px' }}>Add New Patient</button>

            {isAddingPatient ? (
                <PatientForm onPatientRegistered={handlePatientRegistered} />
            ) : (
                <ul style={{ listStyleType: 'none', padding: 0 }}>
                    {patients.map((patient) => (
                        <li key={patient.identityNumber} style={{ padding: '10px', borderBottom: '1px solid #eaeaea' }}>
                            {patient.name} {patient.surname} - Age: {patient.age}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default ManagePatients;