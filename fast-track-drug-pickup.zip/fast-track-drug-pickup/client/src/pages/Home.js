import React from 'react';

const Home = () => {
    return (
        <div style={styles.container}>
            <div style={styles.header}>
                <h1 style={styles.title}>Welcome to St Albert's Hospital</h1>
                <p style={styles.subtitle}>Your health is our priority!</p>
            </div>

            <div style={styles.graphicShapes}>
                {Array.from({ length: 20 }).map((_, index) => (
                    <div key={index} style={getRandomPillStyle()}></div>
                ))}
            </div>

            <div style={styles.messageContainer}>
                <h2 style={styles.welcomeMessage}>Fast Track Drug Pickup Service</h2>
                <p style={styles.description}>
                    We provide a seamless and efficient service for our patients to collect their medication quickly and safely.
                </p>
            </div>
        </div>
    );
};

// Function to generate random pill styles
const getRandomPillStyle = () => {
    const colors = ['#ff4d4d', '#66ff66', '#66b3ff', '#ffcc99', '#ffb3b3'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    return {
        width: '60px',
        height: '30px',
        background: `linear-gradient(to right, ${randomColor} 50%, #ffffff 50%)`,
        borderRadius: '15px',
        margin: '10px', // Space between pills
    };
};

// Styles for the HomePage component
const styles = {
    container: {
        padding: '20px',
        textAlign: 'center',
        backgroundColor: '#007BFF', // Blue background color
        minHeight: '100vh',
        color: '#fff', // White text color for contrast
        fontFamily: 'Arial, sans-serif',
    },
    header: {
        marginBottom: '30px',
        backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background for better readability
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)',
    },
    title: {
        fontSize: '2.5em',
        margin: '0',
    },
    subtitle: {
        fontSize: '1.2em',
        margin: '0',
    },
    graphicShapes: {
        display: 'flex',
        flexWrap: 'wrap', // Allow pills to wrap to the next line
        justifyContent: 'center', // Center the pills horizontally
        alignItems: 'flex-start', // Align pills to the top
        marginBottom: '20px', // Space between pills and message container
    },
    messageContainer: {
        margin: '20px auto',
        maxWidth: '600px',
        padding: '15px',
        borderRadius: '8px',
        backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background for better readability
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    },
    welcomeMessage: {
        fontSize: '2em',
        margin: '0',
    },
    description: {
        fontSize: '1.2em',
        margin: '0',
    },
};

export default Home;