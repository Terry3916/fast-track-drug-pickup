import React from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
    const navigate = useNavigate();

    const handleManagePatientsClick = () => {
        navigate('/managepatients');
    };

    // Replace the following with actual data fetching logic
    const totalPatients = 0;
    const undetectableVL = 0;
    const suppressedVL = 0;
    const unsuppressedVL = 0;

    return (
        <div style={styles.container}>
            <h2>Your Dashboard</h2>
            <p>This is your dashboard where you can manage patients and view reports.</p>
            <h3>Patient Statistics</h3>
            <ul>
                <li>Total Patients: {totalPatients}</li>
                <li>Undetectable Viral Load: {undetectableVL}</li>
                <li>Suppressed Viral Load: {suppressedVL}</li>
                <li>Unsuppressed Viral Load: {unsuppressedVL}</li>
            </ul>
            <h3>Manage Patients</h3>
            <button onClick={handleManagePatientsClick}>Go to Patient Management</button>
            <h3>Reports</h3>
            <button onClick={() => {/* Navigate to Reports */}}>View Reports</button>
        </div>
    );
};

const styles = {
    container: {
        padding: '20px',
        maxWidth: '800px',
        margin: 'auto',
        fontFamily: 'Arial, sans-serif',
    },
};

export default Dashboard;