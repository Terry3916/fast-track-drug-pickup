import axios from 'axios';

// Register User
export const registerUser = async (userData) => {
    try {
        const response = await axios.post('/api/users/register', userData);
        return response.data;
    } catch (error) {
        throw error.response.data;
    }
};

// Login User
export const loginUser = async (credentials) => {
    try {
        const response = await axios.post('/api/users/login', credentials);
        return response.data;
    } catch (error) {
        throw error.response.data;
    }
};

// Additional service methods for user management can be added here.