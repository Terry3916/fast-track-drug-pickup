// client/src/services/patientService.js
import axios from 'axios';

const BASE_URL = 'http://localhost:5000/api/patients'; // Ensure this matches your server URL

const getAuthHeaders = () => {
    const token = localStorage.getItem('token'); // Get the token from local storage
    return { headers: { Authorization: token } }; // Set the token in the headers
};

// Register a new patient
export const registerPatient = async (patient) => {
    try {
        const response = await axios.post(BASE_URL, patient, getAuthHeaders());
        return response.data; // Return the response data
    } catch (error) {
        console.error('Error registering patient:', error);
        throw error; // Rethrow the error to be handled in the component
    }
};

// Fetch all patients
export const getAllPatients = async () => {
    try {
        const response = await axios.get(BASE_URL, getAuthHeaders());
        return response.data; // Return the data of patients
    } catch (error) {
        console.error('Error fetching patients:', error);
        throw error; // Rethrow the error to be handled in the component
    }
};