module.exports = {
    jwtSecret: 'your_jwt_secret', // Use a more secure way to manage secrets in production
};