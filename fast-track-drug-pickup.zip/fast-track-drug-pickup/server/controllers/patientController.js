const Patient = require('../models/Patient');

// Register a new patient
exports.registerPatient = async (req, res) => {
    const { name, surname, age, sex, identityNumber, viralLoad, lastTestDate, regimen } = req.body;

    const patient = new Patient({ name, surname, age, sex, identityNumber, viralLoad, lastTestDate, regimen });

    try {
        await patient.save();
        res.status(201).json({ message: 'Patient registered successfully', patient });
    } catch (error) {
        res.status(500).json({ message: 'Error registering patient', error });
    }
};

// Update patient viral load and eligibility
exports.updatePatient = async (req, res) => {
    const { id } = req.params;
    const { viralLoad } = req.body;

    try {
        const patient = await Patient.findById(id);
        if (!patient) return res.status(404).json({ message: 'Patient not found' });

        patient.viralLoad = viralLoad;
        patient.lastTestDate = new Date();

        if (viralLoad === 0) {
            patient.eligibility = true; // Fast track eligibility
            patient.appointmentDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000); // 1 year later
        } else if (viralLoad <= 1000) {
            patient.eligibility = false; // Not eligible for fast track
            patient.appointmentDate = new Date(Date.now() + 3 * 30 * 24 * 60 * 60 * 1000); // 3 months later
            patient.notes = "Refer for Enhanced Adherence Counseling (E.A.C)";
        } else {
            patient.eligibility = false; // Not eligible for fast track
            patient.appointmentDate = new Date(Date.now() + 3 * 30 * 24 * 60 * 60 * 1000); // 3 months later
            patient.notes = "Switch to appropriate ARV regimen";
        }

        await patient.save();
        res.json(patient);
    } catch (error) {
        res.status(500).json({ message: 'Error updating patient', error });
    }
};

// Generate reports
exports.generateReports = async (req, res) => {
    try {
        const totalPatients = await Patient.countDocuments();
        const undetectable = await Patient.countDocuments({ viralLoad: 0 });
        const suppressed = await Patient.countDocuments({ viralLoad: { $gt: 0, $lte: 1000 } });
        const unsuppressed = await Patient.countDocuments({ viralLoad: { $gt: 1000 } });

        res.json({ totalPatients, undetectable, suppressed, unsuppressed });
    } catch (error) {
        res.status(500).json({ message: 'Error generating reports', error });
    }
};

// Upload patient data from Excel
exports.uploadPatientsFromExcel = async (req, res) => {
    // Implement Excel file parsing and patient registration logic here
    res.json({ message: 'Upload functionality not implemented yet' });
};