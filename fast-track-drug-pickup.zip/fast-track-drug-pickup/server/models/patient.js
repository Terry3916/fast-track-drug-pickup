const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
    name: String,
    surname: String,
    age: Number,
    sex: String,
    identityNumber: { type: String, required: true, unique: true },
    viralLoad: { type: Number, required: true }, // Current viral load
    lastTestDate: { type: Date, required: true },
    eligibility: { type: Boolean, default: false }, // Fast track eligibility
    appointmentDate: { type: Date }, // Next appointment
    regimen: String, // Current ARV regimen
    notes: String // Additional notes
});

module.exports = mongoose.model('Patient', patientSchema);