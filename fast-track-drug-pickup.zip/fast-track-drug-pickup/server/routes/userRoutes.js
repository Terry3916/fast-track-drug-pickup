const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');

// Register User
router.post('/register', async (req, res) => {
    const { name, surname, age, sex, role, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, surname, age, sex, role, password: hashedPassword });
    await user.save();
    res.status(201).send('User registered');
});

// More routes for login, update, delete, etc.

module.exports = router;