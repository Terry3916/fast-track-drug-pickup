const express = require('express');
const router = express.Router();
const { login, register } = require('../controllers/authController'); // Importing both functions

router.post('/login', login);
router.post('/register', register); // Added register route

module.exports = router;