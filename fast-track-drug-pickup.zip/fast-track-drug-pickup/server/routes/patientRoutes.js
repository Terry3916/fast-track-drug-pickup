const express = require('express');
const router = express.Router();
const {
    registerPatient,
    updatePatient,
    generateReports,
    uploadPatientsFromExcel
} = require('../controllers/patientController');
const auth = require('../middleware/auth');

router.use(auth); // Protect all routes with authentication

router.post('/', registerPatient); // Register a new patient
router.put('/:id', updatePatient); // Update patient info
router.get('/reports', generateReports); // Generate reports
router.post('/upload', uploadPatientsFromExcel); // Upload patients from Excel

module.exports = router;